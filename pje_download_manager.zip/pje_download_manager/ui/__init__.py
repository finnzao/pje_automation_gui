"""
Modulo de interface grafica do PJE Automation.
"""

from .credential_manager import CredentialManager, PreferencesManager

__all__ = ["CredentialManager", "PreferencesManager"]
